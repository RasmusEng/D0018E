from flask import Blueprint, abort, jsonify
import psycopg
from ..db import *
products_bp = Blueprint('products', __name__)


@products_bp.route('/products', methods=['GET'])
def get_all_products():
    db = get_db()
    with db.db.cursor() as cur:

        cur.execute(
            "SELECT * FROM products;"
        )

        products = cur.fetchall()

    if products is None:
        abort(404)

    return jsonify(products)

# Add so reviews are also sent
@products_bp.route('/products/<int:productID>', methods=['GET'])
def get_product_by_id(productID):
    db = get_db()
    with db.db.cursor() as cur:

        cur.execute(
            "SELECT * FROM products WHERE product_id = %(id)s;", {
                'id': productID}
        )
        product = cur.fetchone()

    if product is None:
        abort(404, description="No product with provided product id found")

    return jsonify(product)
