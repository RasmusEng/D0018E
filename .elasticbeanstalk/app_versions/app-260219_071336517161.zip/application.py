from flask import Flask
import os
import psycopg



database_url = os.environ.get("RDS_HOSTNAME")

db_host = os.environ.get("RDS_HOSTNAME")
db_port = os.environ.get("RDS_PORT", "5432")
db_name = os.environ.get("RDS_DB_NAME")
db_user = os.environ.get("RDS_USERNAME")
db_password = os.environ.get("RDS_PASSWORD")

if all([db_host, db_name, db_user, db_password]):
    database_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
else:
    database_url = "Database not configured"

# print a nice greeting.
def say_hello(username = "World"):
    return '<p>Hello %s!</p>\n' % username

# some bits of text for the page.
header_text = '''
    <html>\n<head> <title>EB Flask Test</title> </head>\n<body>'''
instructions = '''
    <p><em>Hint</em>: This is a RESTful web service! Append a username
    to the URL (for example: <code>/Thelonious</code>) to say hello to
    someone specific.</p>\n'''
home_link = '<p><a href="/">Back</a></p>\n'
footer_text = '</body>\n</html>\n<p>Database URL: %s</p>' % database_url


# EB looks for an 'application' callable by default.
application = Flask(__name__)

# add a rule for the index page.
application.add_url_rule('/', 'index', (lambda: header_text +
    say_hello() + instructions + footer_text))

# add a rule when the page is accessed with a name appended to the site
# URL.
application.add_url_rule('/<username>', 'hello', (lambda username:
    header_text + say_hello(username) + home_link + footer_text))

def db_test():
    try:
        with psycopg.connect(database_url) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1;")
                result = cur.fetchone()
        return f"<p>DB Connected! Result: {result}</p>"
    except Exception as e:
        return f"<p>DB ERROR: {e}</p>"

application.add_url_rule('/dbtest', 'dbtest', db_test)


# run the app.
if __name__ == "__main__":
    # Setting debug to True enables debug output. This line should be
    # removed before deploying a production app.
    application.debug = True
    application.run()