from flask import Flask
import os
import psycopg
from psycopg.rows import dict_row
import html

# EB looks for an 'application' callable by default.
application = Flask(__name__)

def get_database_url() -> str:
    # Prefer DATABASE_URL if you set it yourself in EB env vars
    db_url = os.environ.get("DATABASE_URL")
    if db_url:
        return db_url

    # Otherwise use EB RDS_* env vars
    host = os.environ.get("RDS_HOSTNAME")
    port = os.environ.get("RDS_PORT", "5432")
    name = os.environ.get("RDS_DB_NAME")
    user = os.environ.get("RDS_USERNAME")
    pw   = os.environ.get("RDS_PASSWORD")

    if not all([host, name, user, pw]):
        raise RuntimeError("Database env vars not set. Set DATABASE_URL or attach RDS to EB (RDS_* vars).")

    return f"postgresql://{user}:{pw}@{host}:{port}/{name}"

DATABASE_URL = get_database_url()

header_text = """\
<html>
<head><title>EB Flask Test</title></head>
<body>
<h1>Users</h1>
"""

footer_text = """\
</body>
</html>
"""

def render_users_table() -> str:
    try:
        with psycopg.connect(DATABASE_URL) as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM users ORDER BY 1;")
                rows = cur.fetchall()

        if not rows:
            return "<p>No users found.</p>"

        # Columns from the first row dict
        cols = list(rows[0].keys())

        # Build HTML table
        table = ["<table border='1' cellpadding='6' cellspacing='0'>"]
        table.append("<thead><tr>" + "".join(f"<th>{html.escape(str(c))}</th>" for c in cols) + "</tr></thead>")
        table.append("<tbody>")
        for r in rows:
            table.append("<tr>" + "".join(f"<td>{html.escape(str(r[c]))}</td>" for c in cols) + "</tr>")
        table.append("</tbody></table>")

        return "\n".join(table)

    except Exception as e:
        # Don't leak secrets; this is safe-ish, but you may want to log it instead
        return f"<p>DB ERROR: {html.escape(str(e))}</p>"

def users_page():
    return header_text + render_users_table() + footer_text

# Serve the table at both / and /users
application.add_url_rule("/", "index", users_page)
application.add_url_rule("/users", "users", users_page)

if __name__ == "__main__":
    application.run(debug=True)
